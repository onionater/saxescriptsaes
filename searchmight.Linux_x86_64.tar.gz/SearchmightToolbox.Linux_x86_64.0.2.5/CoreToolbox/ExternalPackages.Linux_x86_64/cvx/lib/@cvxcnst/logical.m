function x = logical( v )
error( sprintf( 'Disciplined convex programming error:\n   Constraints may not appear in if/then statements.' ) );
