function y = cvx_constant( x )
error( nargchk( 1, 1, nargin ) );
y = x;

% Copyright 2008 Michael C. Grant and Stephen P. Boyd. 
% See the file COPYING.txt for full copyright information.
% The command 'cvx_where' will show where this file is located.
