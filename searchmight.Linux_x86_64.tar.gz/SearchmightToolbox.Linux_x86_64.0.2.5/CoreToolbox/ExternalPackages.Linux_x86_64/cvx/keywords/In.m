function y = In
y = cvxin;
