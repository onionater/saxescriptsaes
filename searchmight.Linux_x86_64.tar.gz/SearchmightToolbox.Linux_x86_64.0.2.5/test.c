#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) {

  /* this is just a test */
  printf("just a test\n");fflush(stdout);


}
